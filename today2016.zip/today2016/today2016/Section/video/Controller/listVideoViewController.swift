//
//  listVideoViewController.swift
//  today2016
//
//  Created by wanghui on 16/3/3.
//  Copyright © 2016年 王辉. All rights reserved.
//

import UIKit


class listVideoViewController: UIViewController {
    var ID = 0
    let listurl = "http://v.jxvdy.com/sendfile/KYSjy5JI1S3H_zm_Xx0IJldSgvxTsYmOBxzD_z_mVcIQ9JVFP5zZ93p7wzMA7e3Noj0HG2GKKBlFT7gTzkZJYJWNQhflkw"
    //数据源
    lazy var dataArr:NSMutableArray = NSMutableArray (capacity: 1);
    
    @IBOutlet var heightOfPlayView: NSLayoutConstraint!
    @IBOutlet var playerView: UIView!

    //播放或暂停
    @IBAction func playOrPauseBtn(sender: AnyObject) {
    }
    //全屏
    
    @IBAction func fullScreenBtn(sender: AnyObject) {
    }
    //进度条
    
    @IBOutlet var progressSlider: UISlider!
    var avPlayer :AVPlayer!//播放器
    var playerItme:AVPlayerItem!//播放项目
    var layer:AVPlayerLayer!
    var isFullScreen:Bool!
    var isEnd:Bool!
    var movieURL:String!
     
    


    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //初始化AVPlayer
        self.layer = AVPlayerLayer(player: self.avPlayer)
        self.layer.frame = CGRectMake(0, 20, 375, 200)
        self.playerView.layer.insertSublayer(self.layer, atIndex: 0)
        self.heightOfPlayView.constant = 200;
        
        let movieurl = NSURL(string: self.listurl)
        self.playerItme = AVPlayerItem(URL:movieurl!)
        self.avPlayer = AVPlayer(playerItem:self.playerItme)
        self.avPlayer.play()

                
//        self.playerItme!.addObserver(self, forKeyPath: "status", options: .New, context:nil  )
//        self.playerItme!.addObserver(self, forKeyPath: "loadedTimeRanges", options: .New, context: nil)
//        NSNotificationCenter.defaultCenter().addObserver(self, selector: "myMovieFinishedCallback", name: AVPlayerItemDidPlayToEndTimeNotification, object: self.playerItme)
    
  
    }
      
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
  
    
    @IBAction func backBtn(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    //将属性声明为setter和getter方法
    var listID:Int {
        set {
          self.ID = newValue

      }
        get {
        return 20
        }
    }
    

}