//
//  VideoViewController.h
//  today2016
//
//  Created by wanghui on 16/3/2.
//  Copyright © 2016年 王辉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoViewController : UICollectionViewController

@end
