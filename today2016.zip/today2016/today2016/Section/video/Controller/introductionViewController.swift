//
//  introductionViewController.swift
//  today2016
//
//  Created by wanghui on 16/3/3.
//  Copyright © 2016年 王辉. All rights reserved.
//

import UIKit

class introductionViewController: UITableViewController {
    var model:listVideoModel!
    var ID: Int!
    //初始化数组
    lazy var dataSourceArr:NSMutableArray = NSMutableArray(capacity: 1)
    
    //将属性声明为setter和getter方法
    var listID:Int {
        set {
            self.ID = newValue
        }
        get {
            return 20
        }
    }


    override func viewDidLoad() {
        super.viewDidLoad()
       self.tableView.estimatedRowHeight = 40.0
        self.tableView.rowHeight = UITableViewAutomaticDimension
        
        //通知中心  通知中心的使用时机,即注册通知中心的的界面先于消息发送界面产生,不然消息发送者没有接受者
        /**
        1.是一种消息广播机制,是为了应用程序中对象解耦而设计的
        2.是观察者模式的一种,提供了注册和一处的接口.当注册为观察者后,如果收到相应的消息,观察者就会接受对应的消息,并做出处理
        */
        /*
     //以单例方式注册通知中心  通知中心方法的使用
    let notificationCenter:NSNotificationCenter = NSNotificationCenter.defaultCenter()
        notificationCenter.addObserver(self, selector:"notificationCenterSender" , name: "dataSource", object: nil)
    }
    //注意 这里的方法实现 swift中方法使用和OC中的不同
    func notificationCenterSender(model:NSNotification) {
       let model = model.object as! listVideoModel
        self.dataSourceArr.addObject(model)
        self.tableView.reloadData()
        */
        
        //解析数据
      print("++++______+++++\(self.ID)")
//         let urlStr = "http://api2.jxvdy.com/video_info?token=(null)&id=\(ID)"
//        let url = NSURL(string: urlStr)
//        let  request = NSURLRequest(URL: url!)
//        let session = NSURLSession.sharedSession()
//        let dataTask = session.dataTaskWithRequest(request) { (data :NSData?, resposne : NSURLResponse?, error : NSError?) -> Void in
//            let dic = try!NSJSONSerialization.JSONObjectWithData(data!, options:NSJSONReadingOptions.AllowFragments)
//            let model = listVideoModel.init(dic: dic as! NSDictionary)
//            print("-0---\(model.title)")
//           
//            
//        }
//        dataTask.resume()
        

    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 1
    }


    //在这里实现传值
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("listVideoViewCell", forIndexPath: indexPath)as!listVideoViewCell
        //注意这里给model赋值时的类型
        if self.dataSourceArr.count > 0 {
        cell.listModel = self.dataSourceArr[indexPath.row] as! listVideoModel
        }
        return cell
    }


    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
