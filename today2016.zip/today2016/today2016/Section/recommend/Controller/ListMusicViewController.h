//
//  ListMusicViewController.h
//  today2016
//
//  Created by wanghui on 16/3/1.
//  Copyright © 2016年 王辉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListMusicViewController : UITableViewController
@property (nonatomic,assign)NSInteger albumId;
@end
