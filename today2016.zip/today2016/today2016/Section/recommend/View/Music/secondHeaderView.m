//
//  secondHeaderView.m
//  today2016
//
//  Created by wanghui on 16/3/5.
//  Copyright © 2016年 王辉. All rights reserved.
//

#import "secondHeaderView.h"

@implementation secondHeaderView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
