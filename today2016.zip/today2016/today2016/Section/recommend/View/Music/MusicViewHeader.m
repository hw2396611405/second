//
//  MusicViewHeader.m
//  today2016
//
//  Created by wanghui on 16/2/29.
//  Copyright © 2016年 王辉. All rights reserved.
//

#import "MusicViewHeader.h"

@interface MusicViewHeader ()

@end

@implementation MusicViewHeader
- (IBAction)moreBtn:(id)sender {
}

- (void)awakeFromNib {
    // Initialization code
}

@end
